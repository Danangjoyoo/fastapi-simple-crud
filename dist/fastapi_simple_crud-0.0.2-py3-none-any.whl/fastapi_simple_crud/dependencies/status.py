class StatusResponse:
    success = 0
    error = 100
    data_is_not_exist = 4
    data_not_updated = 22